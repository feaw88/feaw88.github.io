function clickcloseline() {
    document.getElementById("topbar").innerHTML = "  <div class='row floatbardesign'><h2 class='floatbartext'>Add Friend</h2><a class='imgflot' target='_blank' href='https://lin.ee/a8abhjq'><img src='/asset/M.png'></a><span class='floatbartext'>LINE ID : @feaw88</span><p class='floatbardark' onclick='clickcloseline()'>เปิดหน้าต่าง</p></div> ";
}